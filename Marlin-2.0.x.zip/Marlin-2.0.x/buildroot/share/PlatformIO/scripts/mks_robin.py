#
# mks_robin.py
#
import robin
robin.prepare("0x08007000", "mks_robin.ld", "Robin.bin")
