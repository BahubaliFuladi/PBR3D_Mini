#
# mks_robin_lite3.py
#
import robin
robin.prepare("0x08005000", "mks_robin_lite.ld", "mksLite3.bin")
